#define CL_TARGET_OPENCL_VERSION 220
#include <CL/cl.h>

int main(void) {
	cl_platform_id id;
	cl_int result;
	result = 0;
	return result;
}
